#include <math.h>

/**** FONCTIONS DEJA FOURNIES *****************************************************************************************/

/** Creer une matrice de taille nrows x ncols.
 *  Si init="random", les elements sont initialises aleatoirement. 
 *  Si init="zero", les elements sont initialises a zero.
 */
void createMatrix(
    double **pmat,
    int nrows,
    int ncols,
    char *init);

/** Desallouer une matrice precedemment cree et mettre le pointeur pmat a NULL.
  */
void destroyMatrix(double **pmat);

/** Multiplier deux matrices A et B de taille MxM et rajouter le resultat dans la matrice C (C = C + A * B).
 */
void multiplyAddMatrix(
    double *A,
    double *B,
    double *C,
    int M);

/** Afficher une matrice de taille nrows * ncols
  */
void printMatrix(
    double *mat,
    int nrows,
    int ncols);

/**** FONCTIONS A IMPLANTER *******************************************************************************************/

/** Algorithme parallele SUMMA pour effectuer la multiplication matrice-matrice C = A x B.
 */
void summa(int N) // Le nombre de lignes/de colonnes de A, B et C
{
  int procRank, numProcs;
  double *A, *B, *C;;
  double *Aloc, *Bloc, *Cloc;
  double *Atemp, *Btemp; // Le blocs a recuperer avec broadcast dans la boucle principale

  // Recuperer procRank et numProcs, puis creer des communicateurs de ligne et de colonne

  // Creer les matrices Aloc, Bloc, Cloc, Atemp et Btemp dans tous les processus

  // (!) Creer les matrices A, B et C dans le processus 0 puis distribuer les a tous les processus (dans Aloc et Bloc)
  
  // Broadcaster le morceau k (k = 1 ... sqrt(numProcs)) de chaque bloc de ligne de A et bloc de colonne de B

  // Effectuer la multiplication locale 

  // Mettre ensemble les resultats dans C du processus 0
}
